<script src="
https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css
" rel="stylesheet">

<section>
  <div class="container">
    <div class="row" style="min-height: 30vh;">
      <div class="col-md-12 justify-content-center align-content-center">
        <h1 style="text-align: center;">Comming soon...</h1>
      </div>
    </div>
  </div>
</section>