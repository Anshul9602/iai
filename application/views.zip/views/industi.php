<script src="
https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css
" rel="stylesheet">

<style>
  .ht h4 {

    font-size: large;
  }

  .ht .mt-3 {
    margin-top: 40px !important;
  }
</style>




<div class="top-barr" style="position: relative;">
  <img class="desk" src="assets/img/ab.png" alt width="100%">
  <img class="mob" src="assets/b.jpg" alt width="100%">
  <div class="cont" style="position: absolute;top:50%;left:50%;transform: translate(-50%, -50%);">
    <h1>Industries We Transform</h1>
    <h4>Tailored AI Solutions for Every Sector</h4>
  </div>
</div>



<div class="" style="max-width: 90%; margin:auto;">
  <div class="row justify-content-center align-items-center ht">
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s1.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Software & Platforms</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s2.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Government & Public Sector</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s3.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Telecommunications</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s4.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Retail</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s5.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Healthcare</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s6.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Transportation & Logistics</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s7.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Finance</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s8.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Consumer Goods & Services</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s9.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Real Estate</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s10.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Energy & Utilities</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s11.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Media & Entertainment</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s12.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Hospitality & Tourism</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s13.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Banking</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s14.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Insurance</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s15.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Education</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s16.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Manufacturing</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s17.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Automotive</h4>
    </div>
    <div class="col-md-3 mt-3">
      <div class="img" style="border-radius: 24px;overflow:hidden;">
        <img src="assets/ind/s18.png" alt width="100%">
      </div>
      <h4 class="p-3 text-start mt-3">Agriculture</h4>
    </div>

  </div>

</div>